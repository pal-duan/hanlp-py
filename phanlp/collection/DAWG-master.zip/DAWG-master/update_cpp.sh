#!/bin/sh
cython src/*.pyx src/*.pxd -a --cplus -2
