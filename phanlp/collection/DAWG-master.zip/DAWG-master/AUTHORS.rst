Authors & Contributors
----------------------

* Mikhail Korobov <kmike84@gmail.com>;
* Dan Blanchard;
* Jakub Wilk;
* Alex Moiseenko;
* `Matt Hickford <https://github.com/matt-hickford>`_;
* `Ikuya Yamada <https://github.com/ikuyamada>`_.

This module uses `dawgdic`_ C++ library by
Susumu Yata & contributors.

base64 decoder is a modified version of libb64_ (original author
is Chris Venter).

.. _libb64: http://libb64.sourceforge.net/
.. _dawgdic: https://code.google.com/p/dawgdic/
